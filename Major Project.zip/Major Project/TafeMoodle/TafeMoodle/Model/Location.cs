﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TafeMoodle.Model
{
    class Location
    {
        public int locationID { get; set; }
        public string address { get; set; }
        public int contactNum { get; set; }

        //Construct
        //public Location(string address, int contactNum)
        //{
        //    this.address = address;
        //    this.contactNum = contactNum;
        //}

        //TODO: Add CRUD Methods 


    }
}
