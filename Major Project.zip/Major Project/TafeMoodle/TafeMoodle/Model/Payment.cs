﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TafeMoodle.Model
{
    class Payment
    {
        public int paymentID { get; set; }
        public DateTime paymentDate { get; set; }

        //Construct 
        //public Payment(int paymentID, DateTime paymentDate)
        //{
        //    this.paymentID = paymentID;
        //    this.paymentDate = paymentDate;
        //}

        //TODO: Add CRUD methods 
    }
}
