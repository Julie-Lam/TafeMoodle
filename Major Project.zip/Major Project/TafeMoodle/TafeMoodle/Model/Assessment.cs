﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TafeMoodle.Model
{
    class Assessment
    {
        public int assessmentID;
        public string assessmentName;
        public string dueDate;
        public string assessmentType;
    }
}
