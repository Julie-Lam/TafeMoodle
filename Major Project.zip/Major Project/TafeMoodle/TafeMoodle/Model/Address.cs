﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TafeMoodle.Model
{
    class Address
    {
        public int addressID;
        public int houseNum;
        public string streetName;
        public string suburb;
        public string state;
        public int postcode;

    }
}
